﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TODODapper.Models;
using TODODapper.Repository;

namespace TODODapper.Controllers
{
    public class TaskController : Controller
    {
        private readonly IRepository _repo;

        public TaskController(IRepository repo)
        {
            _repo = repo;
        }

        public async Task<IActionResult> Index()
        {
            var tasks = await _repo.GetAllTasks();
            //var sortedTasks = tasks.OrderByDescending(t => t.Id);
            return View(tasks);
        }

        [HttpGet]
        public async Task<IActionResult> Create(int id)
        {
            TaskModel t;

            if (id > 0)
            {
                t = await _repo.GetTaskById(id);
                return View(t);
            }
            else
            {
                t = new TaskModel();
                return View(t);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create(TaskModel task)
        {
            if (!ModelState.IsValid) return View(task);
            if(task.Id>0)
            {
                await _repo.UpdateTask(task); return RedirectToAction("Index");//redirect to Index.cshtml file
            }
            else
            {
                await _repo.AddTask(task); return RedirectToAction(nameof(Index));//redirect to Index.cshtml file
            }    
        }

        //public async Task<IActionResult> Edit(int id)
        //{
        //    var task = await _repo.GetTaskById(id);
        //    return View(task);
        //}

        //[HttpPost]
        //public async Task<IActionResult> Edit(TaskModel task)
        //{
        //    if (!ModelState.IsValid) return View(task);
        //    await _repo.UpdateTask(task);
        //    return RedirectToAction(nameof(Index));
        //}

        public async Task<IActionResult> Delete(int id)
        {
            var task = await _repo.GetTaskById(id);
            await _repo.DeleteTask(id);
            return RedirectToAction("Index");
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _repo.DeleteTask(id);
            return RedirectToAction(nameof(Index));
        }
    }

}
