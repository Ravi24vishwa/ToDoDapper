﻿using Microsoft.Extensions.Configuration;
using Microsoft.SqlServer.Server;
using Microsoft.Data.SqlClient;
using System.Data;

namespace TODODapper
{

    public class DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public DbContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("ToDoContextConnection");
        }

        public IDbConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}
