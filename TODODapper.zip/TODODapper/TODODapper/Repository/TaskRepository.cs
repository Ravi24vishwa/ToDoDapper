﻿using Dapper;
using TODODapper.Models;

namespace TODODapper.Repository
{
    public class TaskRepository : IRepository
    {
        private readonly DbContext _db;
        public TaskRepository(DbContext db)
        {
            _db = db;
        }

        public async Task<IEnumerable<TaskModel>> GetAllTasks()
        {
            var sql = "SELECT * FROM ToDoItems";
            using var conn = _db.CreateConnection();
            return await conn.QueryAsync<TaskModel>(sql);
        }

        public async Task<TaskModel> GetTaskById(int id)
        {
            var sql = "SELECT * FROM ToDoItems WHERE Id = @Id";
            using var conn = _db.CreateConnection();
            return await conn.QueryFirstOrDefaultAsync<TaskModel>(sql, new { Id = id });
        }

        public async Task AddTask(TaskModel task)
        {
            var sql = @"INSERT INTO ToDoItems (Title, Description, DueDate, Priority, Status)
                    VALUES (@Title, @Description, @DueDate, @Priority, @Status)";
            using var conn = _db.CreateConnection();
            await conn.ExecuteAsync(sql, task);
        }

        public async Task UpdateTask(TaskModel task)
        {
            var sql = @"UPDATE ToDoItems SET Title=@Title, Description=@Description,
                    DueDate=@DueDate, Priority=@Priority, Status=@Status WHERE Id=@Id";
            using var conn = _db.CreateConnection();
            await conn.ExecuteAsync(sql, task);
        }

        public async Task DeleteTask(int id)
        {
            var sql = "DELETE FROM ToDoItems WHERE Id=@Id";
            using var conn = _db.CreateConnection();
            await conn.ExecuteAsync(sql, new { Id = id });
        }
    }

}
