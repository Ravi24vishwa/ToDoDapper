﻿using TODODapper.Models;

namespace TODODapper.Repository
{
    public interface IRepository
    {
        Task<IEnumerable<TaskModel>> GetAllTasks();
        Task<TaskModel> GetTaskById(int id);
        Task AddTask(TaskModel task);
        Task UpdateTask(TaskModel task);
        Task DeleteTask(int id);
    }

}
